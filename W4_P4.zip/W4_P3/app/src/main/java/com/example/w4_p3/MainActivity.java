package com.example.w4_p3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
        implements GestureDetector.OnGestureListener,
        GestureDetector.OnDoubleTapListener {

    private TextView home_text;
    private GestureDetector gest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        home_text = (TextView) findViewById(R.id.home_text);
        gest = new GestureDetector(this, this);
        gest.setOnDoubleTapListener(this);

    }

    public boolean onTouchEvent(MotionEvent event) {
        this.gest.onTouchEvent(event);

        return super.onTouchEvent(event);
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        return true;
    }

    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        return true;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        return true;
    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        return true;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return true;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        return true;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {

    }

    float onFling_Xpara = 3000;
    float onFling_Ypara = 2400;
    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float x, float y) {
        float sens = 50;
        // for fling north
        if ((x >= -1 * onFling_Xpara && x < onFling_Xpara) && y < -1 * onFling_Ypara){
            Intent i = new Intent(MainActivity.this, Main2Activity.class );
            startActivity(i);
            return true;
        }
        // for fling south
        else if((x >= -1 * onFling_Xpara && x < onFling_Xpara) && y > onFling_Ypara){
            Intent i = new Intent(MainActivity.this, Main3Activity.class );
            startActivity(i);
            return true;
        }
        // for fling west
        else if ((y >= -1 * onFling_Ypara && y < onFling_Ypara) && x < -1 * onFling_Xpara){
            Intent i = new Intent(MainActivity.this, Main4Activity.class );
            startActivity(i);
            return true;
        }
        // for fling east
        else if((y >= -1 * onFling_Ypara && y < onFling_Ypara) && x > onFling_Xpara){
            Intent i = new Intent(MainActivity.this, Main5Activity.class );
            startActivity(i);
            return true;
        }

        return true;
    }
}
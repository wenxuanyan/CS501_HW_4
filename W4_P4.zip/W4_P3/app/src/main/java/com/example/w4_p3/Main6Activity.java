package com.example.w4_p3;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Main6Activity extends AppCompatActivity {

    private TextView north_fling;
    private ImageView north_img;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_north);
        north_fling = (TextView) findViewById(R.id.north_fling);
        north_img = (ImageView) findViewById(R.id.north_img);

    }
}
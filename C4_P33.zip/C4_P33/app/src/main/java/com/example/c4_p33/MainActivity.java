package com.example.c4_p33;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button Encrypt;
    private Button Decrypt;
    private EditText input;
    private EditText cipher;
    private EditText key;
    private TextView output;
    private static final String alphabetString = "abcdefghijklmnopqrstuvwxyz";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Encrypt = findViewById(R.id.encrypt);
        Decrypt = findViewById(R.id.decrypt);
        output = findViewById(R.id.tV1);
        input = findViewById(R.id.inputtext);
        cipher = findViewById(R.id.ciphertext);
        key = findViewById(R.id.keyvalue);

        Encrypt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Encrypt3(input.getText().toString(), Integer.parseInt(key.getText().toString()));
            }
        });

        Decrypt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Decrypt3(cipher.getText().toString(), Integer.parseInt(key.getText().toString()));
            }
        });
    }
    public void Decrypt3(String cipher, int key){
        output.setText((MainActivity2.decrypt1(cipher, key).toLowerCase()));

    }
    public String Encrypt3(String input, int shiftkey) {

        input = input.toLowerCase();
        String cipherText = "";
        for (int i = 0; i < input.length(); i++) {
            int charPosition = alphabetString.indexOf(input.charAt(i));
            int keyval = (shiftkey + charPosition) % 26;
            char replaceVAL = alphabetString.charAt(keyval);
            cipherText += replaceVAL;
            output.setText(cipherText);
            cipher.setText(cipherText);
        }
        return cipherText;
    }

}
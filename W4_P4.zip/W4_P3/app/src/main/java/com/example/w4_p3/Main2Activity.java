package com.example.w4_p3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    private TextView north_fling;
    private ImageView north_img;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_north);
        north_fling = (TextView) findViewById(R.id.north_fling);
        north_img = (ImageView) findViewById(R.id.north_img);

    }
}
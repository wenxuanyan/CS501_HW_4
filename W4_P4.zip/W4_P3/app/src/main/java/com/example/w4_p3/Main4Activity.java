package com.example.w4_p3;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Main4Activity extends AppCompatActivity {

    private TextView west_fling;
    private ImageView west_img;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_west);
        west_fling = (TextView) findViewById(R.id.west_fling);
        west_img = (ImageView) findViewById(R.id.west_img);

    }
}
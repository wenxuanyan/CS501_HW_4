package com.example.w4_p3;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Main5Activity extends AppCompatActivity {

    private TextView east_fling;
    private ImageView east_img;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_east);
        east_fling = (TextView) findViewById(R.id.east_fling);
        east_img = (ImageView) findViewById(R.id.east_img);

    }
}
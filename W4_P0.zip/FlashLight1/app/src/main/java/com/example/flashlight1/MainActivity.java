package com.example.flashlight1;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener{
    private CameraManager mCameraManager;
    private String mCameraId;
    private Switch onoff;
    private ConstraintLayout cl;
    private ConstraintLayout.LayoutParams clp;
    private EditText tv;
    private GestureDetector GD;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        GD =new GestureDetector(this, this);
        boolean isFlashAvailable = getApplicationContext().getPackageManager()
                .hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT);

        if (!isFlashAvailable) {
            showNoFlashError();
        }

        mCameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            mCameraId = mCameraManager.getCameraIdList()[0];
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
        tv = (EditText) findViewById(R.id.actionTextBox);
        onoff = new Switch(this);

        cl = (ConstraintLayout) findViewById(R.id.cl);
        clp = new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        //tv.setLayoutParams(new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        onoff.setLayoutParams(new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        cl.addView(onoff);
        tv.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override

            public void afterTextChanged(Editable editable) {
                if(editable.toString().equals("on")){
                    try {
                        mCameraManager.setTorchMode(mCameraId, true);
                        onoff.setChecked(true);
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }else if(editable.toString().equals("off")){
                    try {
                        mCameraManager.setTorchMode(mCameraId, false);
                        onoff.setChecked(false);
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        onoff.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                try {
                    mCameraManager.setTorchMode(mCameraId, isChecked);
                    if(isChecked){
                        tv.setText("on");
                    }else  tv.setText("off");
                } catch (CameraAccessException e) {
                    e.printStackTrace();
                }
            }
        });


    }

    public void showNoFlashError() {
        //Catch the case when there is no flash light
        AlertDialog alert = new AlertDialog.Builder(this).create();
        alert.setTitle("Oops!");
        alert.setMessage("Flash not available in this device...");
        alert.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        alert.show();
    }
    public boolean onTouchEvent(MotionEvent event) {
        this.GD.onTouchEvent(event);
        return super.onTouchEvent(event);
    }
    @Override
    public boolean onDown(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {

        return false;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        if(Math.abs(motionEvent.getY()-motionEvent1.getY())>300.00) {
            //300.00 to avoid accidentally swipe
            try {
                if (motionEvent.getY() > motionEvent1.getY()) {
                    tv.setText("on");
                    onoff.setChecked(true);
                    mCameraManager.setTorchMode(mCameraId, true);
                } else {
                    tv.setText("off");
                    onoff.setChecked(false);
                    mCameraManager.setTorchMode(mCameraId, false);
                }
            } catch (CameraAccessException e) {
                e.printStackTrace();
            }
        }
        return true;
    }
}
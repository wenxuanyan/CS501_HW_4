package com.example.w4_p3;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Main3Activity extends AppCompatActivity {

    private TextView south_fling;
    private ImageView south_img;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_south);
        south_fling = (TextView) findViewById(R.id.north_fling);
        south_img = (ImageView) findViewById(R.id.north_img);

    }
}
package com.example.w4_p2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity
        implements GestureDetector.OnGestureListener,
        GestureDetector.OnDoubleTapListener{

    private TextView tv_dollar;
    private EditText tf_dollar;
    private TextView tv_yuan;
    private TextView tv_yuan_num;
    private TextView tv_yen;
    private TextView tv_yen_num;
    private TextView tv_won;
    private TextView tv_won_num;
    private TextView tv_pound;
    private TextView tv_pound_num;
    private TextView tv_franc;
    private TextView tv_franc_num;
    private TextView test;
    private TextView test2;

    private GestureDetector GD;

    private String to_yuan(double input) {
        double number = 6.34 * input;
        String str = String.format("%.2f", number);

        return str;
    }

    private String to_yen(double input) {
        double number = 115.02 * input;
        String str = String.format("%.2f", number);

        return str;
    }

    private String to_won(double input) {
        double number = 1198.06 * input;
        String str = String.format("%.2f", number);

        return str;
    }

    private String to_pound(double input) {
        double number = 0.73 * input;
        String str = String.format("%.2f", number);

        return str;

    }

    private String to_franc(double input) {
        double number = 0.92 * input;
        String str = String.format("%.2f", number);

        return str;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tf_dollar = (EditText) findViewById(R.id.tf_dollar);
        tv_yuan_num = (TextView) findViewById(R.id.tv_yuan_num);
        tv_yen_num = (TextView) findViewById(R.id.tv_yen_num);
        tv_won_num = (TextView) findViewById(R.id.tv_won_num);
        tv_pound_num = (TextView) findViewById(R.id.tv_pound_num);
        tv_franc_num = (TextView) findViewById(R.id.tv_franc_num);
        test = (TextView) findViewById(R.id.test);
        test2 = (TextView) findViewById(R.id.test2);

        GD = new GestureDetector(this, this);
        GD.setOnDoubleTapListener(this);

        tf_dollar.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {

            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                String input_string = tf_dollar.getText().toString();
                if (input_string.equals("")) {
                    tf_dollar.setText("0.00");
                    return;
                }
                else if (input_string.charAt(0) == '-' || input_string.charAt(0) == '.'){
                    tf_dollar.setText("0.00");
                    return;
                }
                else if(! input_string.equals("0.00") && input_string.charAt(0) == '0'){
                    tf_dollar.setText("0.00");
                    return;
                }


                String input_string_filtered = PerfectDecimal(input_string, Integer.MAX_VALUE, 2);

                if (!input_string_filtered.equals(input_string)) {
                    tf_dollar.setText(input_string_filtered);
                    tf_dollar.setSelection(input_string_filtered.length());
                }


                double input_double = Double.parseDouble(input_string_filtered);


                tv_yuan_num.setText(to_yuan(input_double));
                tv_yen_num.setText(to_yen(input_double));
                tv_won_num.setText(to_won(input_double));
                tv_pound_num.setText(to_pound(input_double));
                tv_franc_num.setText(to_franc(input_double));


            }

        });


    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        this.GD.onTouchEvent(event);

        return super.onTouchEvent(event);
    }




    double scroll_sum = 0;

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        scroll_sum = 0;
        return true;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {
    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return true;
    }


    float onScroll_para = 60;

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float distanceX, float distanceY) {

        scroll_sum += distanceY;

        if(scroll_sum > 600){
            cent_increment();
            scroll_sum = 0;
            return true;
        }
        else if(scroll_sum < -600){
            cent_decrement();
            scroll_sum = 0;
            return true;
        }


//      test code:
//      test2.setText("onScroll " + distanceX + " " + distanceY);


        return true;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {

    }

    float onFling_Xpara = 3000;
    float onFling_Ypara = 2400;
    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {

        if ((velocityX >= -1 * onFling_Xpara && velocityX < onFling_Xpara) && velocityY < -1 * onFling_Ypara){
            dollar_increment();
            return true;
        }

        if((velocityX >= -1 * onFling_Xpara && velocityX < onFling_Xpara) && velocityY > onFling_Ypara){
            dollar_decrement();
            return true;
        }

//      test code:
//      test.setText("onFLing " + velocityX + " " + velocityY);

        return true;
    }


    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        return true;
    }

    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        return true;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        return true;
    }


    public String PerfectDecimal(String str, int MAX_BEFORE_POINT, int MAX_DECIMAL){
        if(str.charAt(0) == '.') str = "0"+str;
        int max = str.length();

        String rFinal = "";
        boolean after = false;
        int i = 0, up = 0, decimal = 0; char t;
        while(i < max){
            t = str.charAt(i);
            if(t != '.' && after == false){
                up++;
                if(up > MAX_BEFORE_POINT) return rFinal;
            }else if(t == '.'){
                after = true;
            }else{
                decimal++;
                if(decimal > MAX_DECIMAL)
                    return rFinal;
            }
            rFinal = rFinal + t;
            i++;
        }return rFinal;

    }

    public void dollar_decrement(){
        String input_string = tf_dollar.getText().toString();

        double input_double = Double.parseDouble(input_string);

        input_double -= 1;

        if (input_double < 0.0){
            tf_dollar.setText("0.00");
        }else{
            tf_dollar.setText(String.format("%.2f", input_double));
        }

        return;
    }

    public void dollar_increment(){
        String input_string = tf_dollar.getText().toString();


        double input_double = Double.parseDouble(input_string);

        input_double += 1;

        if (input_double < 0.0){
            tf_dollar.setText("0.00");
        }else{
            tf_dollar.setText(String.format("%.2f", input_double));
        }

        return;
    }

    public void cent_decrement(){
        String input_string = tf_dollar.getText().toString();

        double input_double = Double.parseDouble(input_string);

        input_double -= 0.1;

        if (input_double < 0.0){
            tf_dollar.setText("0.00");
        }else{
            tf_dollar.setText(String.format("%.2f", input_double));
        }

        return;
    }

    public void cent_increment(){
        String input_string = tf_dollar.getText().toString();

        double input_double = Double.parseDouble(input_string);

        input_double += 0.1;

        if (input_double < 0.0){
            tf_dollar.setText("0.00");
        }else{
            tf_dollar.setText(String.format("%.2f", input_double));
        }

        return;
    }
}



